import pandas as pd
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from webdriver_manager.chrome import ChromeDriverManager

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
driver.maximize_window()

all_products_df = pd.DataFrame(columns=["Product Name", "Product Meta Data", "Product Description"])


for year in range(2023, 2018, -1):  

    if year == 2023:
        months = range(5, 0, -1)  
    else:
        months = range(12, 0, -1)  

    for month in months:
        try:
            all_products_df=pd.read_csv(f"product_data_{year}_{month}_final_1.csv")
            print('loading df')
            print(f"product_data_{year}_{month}_final_1.csv")
        except:
            all_products_df = pd.DataFrame(columns=["Product Name", "Product Meta Data", "Product Description"])
            print('Starting from scratch')
        month_str = f"{month:02d}"
        url = f"https://www.producthunt.com/leaderboard/monthly/{year}/{month_str}"
        print(f"Scraping URL: {url}")
        

        driver.get(url)
        time.sleep(3) 

        if year == 2023 and month == 5:
            i = 279
        else:
            i = 1
        # i=1
        exception_count=0

        while True:
            try:
                if exception_count>10:
                    break
                elif i>1000:
                    break
                
                product_selector = f"#root-container > div > main > div > div:nth-child(2) > div:nth-child({i}) > div > a"
                counter_search=0
                flag=0
                val=driver.find_elements(By.CSS_SELECTOR, product_selector)
                print(val)
                if len(val)==0:
                    product_selector=f"#root-container > div > main > div > div:nth-child(2) > section:nth-child({i}) > div > a"
                    counter_search=0
                    flag=0
                    
                

                # time.sleep(50)

                conditional_selector = f"#root-container > div > main > div > div:nth-child(2) > div:nth-child({i}) > div > div > div > div > div.flex.flex-row.items-center.gap-2 > div"
                conditional_selector_2=f"#root-container > div > main > div > div:nth-child(2) > div:nth-child({i}) > section > div > div.mt-1.flex.flex-col.gap-1 > div > a"
                
                conditional_elements = driver.find_elements(By.CSS_SELECTOR, conditional_selector)
                conditional_elements_2 = driver.find_elements(By.CSS_SELECTOR, conditional_selector_2)

                if conditional_elements:
                    print(f"Skipping product {i} due to specific style.")
                    i += 1
                    time.sleep(3)
                    continue
                
                if conditional_elements_2:
                    print(f"Skipping product {i} due to specific style.")
                    i += 1
                    time.sleep(3)
                    continue
                
                print(product_selector)
                while not driver.find_elements(By.CSS_SELECTOR, product_selector):
                    counter_search+=1
                    print(f"Scrolling to load product {i}...")
                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(3) 
                    if counter_search>20:
                        flag=1
                        break
                if flag==1:
                    i+=1
                    exception_count+=1
                    continue
                WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, product_selector)))

                product_element = driver.find_element(By.CSS_SELECTOR, product_selector)
                
                actions = ActionChains(driver)
                actions.move_to_element(product_element).perform()
                time.sleep(3)  
                
                driver.execute_script("arguments[0].click();", product_element)
                time.sleep(3)
                badge_lst=[]
                img_counter=1
                product_image_urls=[]
                try:
                    time.sleep(3)
                    product_url = driver.current_url
                    # product_name_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\\:flex-row > div.flex.flex-col.gap-2 > h1").text
                    # product_meta_data_new_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\\:flex-row > div.flex.flex-col.gap-2 > h2").text
                    # product_description_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div:nth-child(1) > div.mt-12.flex.flex-col.gap-3 > div.styles_htmlText__eYPgj.text-16.font-normal.text-dark-gray").text
                    # exception_count=0
                    # badge_selector = "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-row > div > div"
                    # vote_count=driver.find_element(By.CSS_SELECTOR,"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\:flex-row > div.flex.flex-row.items-end.gap-3 > button.styles_reset__0clCw.styles_large__O8Tv3.styles_voteButton__lEzEx > div > div.text-14.font-semibold.text-white.uppercase").text
                    # vote_count=vote_count.replace("UPVOTE ","")
                    # image_selector = f"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div.styles_layout__gA7_o.styles_container__eS_WB > div > div > button:nth-child({img_counter}) > div > img"
                    # image_element = driver.find_element(By.CSS_SELECTOR, image_selector)

                    # image_url = image_element.get_attribute("srcset")
                    # final_url=image_url.split("?")[0]
                    # if image_url:
                    #     product_image_urls.append(final_url)
                    #     print(f"Image {img_counter} found for product: {product_name_text}")  
                    # img_counter += 1
                    time.sleep(5)
                    product_name_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\:flex-row > div.flex.flex-col.gap-2 > h1").text
                    product_meta_data_new_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\:flex-row > div.flex.flex-col.gap-2 > h2").text
                    product_description_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div.mt-12.flex.flex-col.gap-3 > div.styles_htmlText__eYPgj.text-16.font-normal.text-dark-gray").text
                    exception_count=0
                    # badge_selector = "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-row > div"
                    vote_count=driver.find_element(By.CSS_SELECTOR,"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\:flex-row > div.flex.flex-row.items-end.gap-3 > button.styles_reset__0clCw.styles_large__O8Tv3.h-16.max-h-16.w-full.sm\:w-auto > div > div.text-14.font-semibold.text-white.uppercase").text
                    vote_count=vote_count.replace("UPVOTE ","")
                    int_vote_count = int(vote_count.replace(",", ""))
                    print(int_vote_count)

                    while True:
                        try:
                            image_selector = f"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div.styles_layout__E_RHA.styles_container__eS_WB > div > div > button:nth-child({img_counter}) > div > img"
                            
                            image_element = driver.find_element(By.CSS_SELECTOR, image_selector)

                            image_url = image_element.get_attribute("srcset")
                            final_url=image_url.split("?")[0]
                            if image_url:
                                product_image_urls.append(final_url)
                                print(f"Image {img_counter} found for product: {product_name_text}")  
                            img_counter += 1
                        except Exception as e:
                            print(f"No more images found for product: {product_name_text}")
                            break

                    # vote_count = vote_count.text.strip().replace(",", "")
                    # print(vote_count)
                    # print(type(vote_count))
                    
                    # # print(type(int_vote_count))

                    # parent_elements = driver.find_elements(By.CSS_SELECTOR, badge_selector)
                    # for parent in parent_elements:
                    #     img_tags = parent.find_elements(By.TAG_NAME, "img")
                        
                    #     for img in img_tags:
                    #         alt_text = img.get_attribute("alt")
                    #         badge_lst.append(alt_text)
                    
                    tags_selector = "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div.mt-12.flex.flex-col.gap-3 > div.flex.flex-col.justify-between.gap-2.sm\:flex-row > div"
                    
                    tags_div = driver.find_element(By.CSS_SELECTOR, tags_selector)

                    tag_names = []
                    tag_urls = []

                    tag_elements = tags_div.find_elements(By.TAG_NAME, "a")

                    for tag in tag_elements:
                        tag_text = tag.text  # Get the visible text of the tag
                        tag_url = tag.get_attribute("href")  # Get the URL of the tag
                        tag_names.append(tag_text)
                        tag_urls.append(tag_url)

                    # Print the extracted tags and URLs (for debugging)
                    tag_names=tag_names[:-1]
                except:

                    product_name_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\:flex-row > div.flex.flex-col.gap-2 > h1").text
                    product_meta_data_new_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\\:flex-row > div.flex.flex-col.gap-2 > h2").text
                    product_description_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div > div:nth-child(1) > div.mt-12.flex.flex-col.gap-3 > div.styles_htmlText__eYPgj.text-16.font-normal.text-dark-gray").text                
                    exception_count=0
                    # vote_count=driver.find_element(By.CSS_SELECTOR,"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\:flex-row > div.flex.flex-row.items-end.gap-3 > button.styles_reset__0clCw.styles_large__O8Tv3.h-16.max-h-16.w-full.sm\:w-auto > div > div.text-14.font-semibold.text-white.uppercase").text
                    # vote_count=vote_count.replace("UPVOTE ","")
                    # int_vote_count = int(vote_count.replace(",", ""))
                    # print(int_vote_count)

                    # while True:
                    #     try:
                    #         image_selector = f"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div.styles_layout__E_RHA.styles_container__eS_WB > div > div > button:nth-child({img_counter}) > div > img"
                            
                    #         image_element = driver.find_element(By.CSS_SELECTOR, image_selector)

                    #         image_url = image_element.get_attribute("srcset")
                    #         final_url=image_url.split("?")[0]
                    #         if image_url:
                    #             product_image_urls.append(final_url)
                    #             print(f"Image {img_counter} found for product: {product_name_text}")  
                    #         img_counter += 1
                    #     except Exception as e:
                    #         print(f"No more images found for product: {product_name_text}")
                    #         break

                product_data = pd.DataFrame({
                    "Product Name": [product_name_text],
                    "Product Meta Data": [product_meta_data_new_text],
                    "Product Description": [product_description_text],
                    "Product Vote Count": [int_vote_count],
                    "Bade List": [badge_lst],
                    "Tags": [tag_names],
                    "Product URL": [product_url],
                    "Product Image URLs": [product_image_urls]
                })
                all_products_df = pd.concat([all_products_df, product_data], ignore_index=True)


                all_products_df.to_csv(f"product_data_{year}_{month}_final_1.csv", index=False)
                print(f"Product {i} from {year}/{month_str} saved to CSV.")

                time.sleep(3)
                close_button = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > a")
                close_button.click()
                time.sleep(5)
                driver.back()
                time.sleep(5)


                i += 1
                
            except Exception as e:
                exception_count+=1
                print(f"Error scraping product at position {i} on {year}/{month_str}: {e}")
                i += 1
                time.sleep(3)
                close_button = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > a")
                if close_button:
                    close_button.click()
                    time.sleep(5)
                    driver.back()
                    time.sleep(5)
                continue
        target_directory="/Users/pranavsharma/Desktop/web-scraper/final_csv"
        file_name=f"product_data_{year}_{month}_final_1.csv"
        file_path = f"{target_directory}/{file_name}"
        all_products_df.to_csv(file_path, index=False)


driver.quit()
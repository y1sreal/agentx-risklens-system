import pandas as pd
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from webdriver_manager.chrome import ChromeDriverManager

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
driver.maximize_window()
driver.set_page_load_timeout(300)  
driver.set_script_timeout(300) 

all_products_df = pd.DataFrame(columns=["Product Name", "Product Image URLs", "Product URL"])


for year in range(2023, 2018, -1):  

    if year == 2024:
        months = range(1, 0, -1)  
    else:
        months = range(8, 0, -1)  

    for month in months:
        all_products_df = pd.DataFrame(columns=["Product Name", "Product Image URLs", "Product URL"])
        month_str = f"{month:02d}"
        url = f"https://www.producthunt.com/leaderboard/monthly/{year}/{month_str}"
        print(f"Scraping URL: {url}")
        

        driver.get(url)
        time.sleep(3) 

        if year == 2024 and month == 2:
            i = 899
        else:
            i = 1
        # i=1
        exception_count=0

        while True:
            target_directory="/Users/pranavsharma/Desktop/web-scraper/image_urls"
            try:
                if exception_count>10:
                    break
                elif i>1000:
                    break

                product_selector = f"#root-container > div > main > div > div:nth-child(2) > div:nth-child({i}) > div > a"
                counter_search=0
                flag=0

                conditional_selector = f"#root-container > div > main > div > div:nth-child(2) > div:nth-child({i}) > div > div > div > div > div.flex.flex-row.items-center.gap-2 > div"
                conditional_elements = driver.find_elements(By.CSS_SELECTOR, conditional_selector)

                if conditional_elements:
                    print(f"Skipping product {i} due to specific style.")
                    i += 1
                    continue

                while not driver.find_elements(By.CSS_SELECTOR, product_selector):
                    counter_search+=1
                    print(f"Scrolling to load product {i}...")
                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(3) 
                    if counter_search>1000:
                        flag=1
                        break
                if flag==1:
                    i+=1
                    exception_count+=1
                    continue
                WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, product_selector)))

                product_element = driver.find_element(By.CSS_SELECTOR, product_selector)
                
                actions = ActionChains(driver)
                actions.move_to_element(product_element).perform()
                time.sleep(3)  
                
                driver.execute_script("arguments[0].click();", product_element)
                time.sleep(3)
                badge_lst=[]
                try:
                    product_url = driver.current_url
                    product_name_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\\:flex-row > div.flex.flex-col.gap-2 > h1").text
                    
                    img_counter=1
                    product_image_urls=[]

                    while True:
                        try:
                            # image_Selector = f"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div.styles_layout__gA7_o.styles_container__eS_WB > div > div > button:nth-child(1) > div > video"
                            image_selector = f"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div.styles_layout__gA7_o.styles_container__eS_WB > div > div > button:nth-child({img_counter}) > div > img"
                            image_element = driver.find_element(By.CSS_SELECTOR, image_selector)

                            image_url = image_element.get_attribute("srcset")
                            final_url=image_url.split("?")[0]
                            if image_url:
                                product_image_urls.append(final_url)
                                print(f"Image {img_counter} found for product: {product_name_text}")  
                            img_counter += 1
                        except Exception as e:
                            print(f"No more images found for product: {product_name_text}")
                            break
                    # next_button=driver.find_element(By.CSS_SELECTOR,"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\/70 > div > div > div.sm\:p-10 > div.styles_layout__gA7_o.styles_container__eS_WB > div > button:nth-child(3) > svg")
                    
                    exception_count=0
                except:

                    product_name_text = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div > div:nth-child(1) > div:nth-child(1) > div.flex.flex-1.flex-col.justify-between.gap-6.sm\\:flex-row > div.flex.flex-col.gap-2 > h1").text
                    img_counter=1
                    product_image_urls=[]

                    while True:
                        try:
                            image_selector = f"#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > div > div > div.sm\\:p-10 > div.styles_layout__gA7_o.styles_container__eS_WB > div > div > button:nth-child({img_counter}) > div > img"
                            image_element = driver.find_element(By.CSS_SELECTOR, image_selector)

                            image_url = image_element.get_attribute("srcset")
                            final_url=image_url.split("?")[0]
                            if image_url:
                                product_image_urls.append(final_url)
                                print(f"Image {img_counter} found for product: {product_name_text}")  
                            img_counter += 1
                        except Exception as e:
                            print(f"No more images found for product: {product_name_text}")
                            break
            
                
                product_data = pd.DataFrame({
                    "Product Name": [product_name_text],
                    "Product Image URLs": [product_image_urls],
                    "Product URL": [product_url]
                })
                all_products_df = pd.concat([all_products_df, product_data], ignore_index=True)

                file_path=f"{target_directory}/image_urls_{year}_{month}.csv"
                all_products_df.to_csv(file_path, index=False)
                print(f"Product {i} from {year}/{month_str} saved to CSV.")

                close_button = driver.find_element(By.CSS_SELECTOR, "#root-container > div.styles_overlay__XLMQA.overlay.fixed.inset-0.z-30.overflow-auto.bg-black\\/70 > a")
                close_button.click()
                time.sleep(2)


                i += 1
                
            except Exception as e:
                exception_count+=1
                print(f"Error scraping product at position {i} on {year}/{month_str}: {e}")
                i += 1
                continue
        target_directory="/Users/pranavsharma/Desktop/web-scraper/final_image_urls"
        file_name=f"image_urls_{year}_{month}_final.csv"
        file_path = f"{target_directory}/{file_name}"
        all_products_df.to_csv(file_path, index=False)
        
        


driver.quit()
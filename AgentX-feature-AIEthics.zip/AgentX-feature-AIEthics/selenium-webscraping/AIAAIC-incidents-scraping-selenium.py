import csv
import time
import requests
from bs4 import BeautifulSoup
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import os
import json 

PUBLISHED_SHEET_URL = (
"https://docs.google.com/spreadsheets/d/e/2PACX-1vQEVkz2crifZnrFiGXs_1NLTExqWX-aIH0l1ep4qKWqB2SF8kjZ6VXr5x_1sqJpoQ/pubhtml?gid=655860870&single=true"
)



def fetch_published_sheet(url):
    """
    Fetches the HTML of the published Google Sheet and returns a BeautifulSoup object.
    """
    print("Fetching published sheet HTML...")
    response = requests.get(url)
    response.raise_for_status()  # If there's an error (4xx or 5xx), this will raise
    soup = BeautifulSoup(response.text, "html.parser")
    return soup


def parse_sheet_data(soup):
    """
    Parses the HTML to extract System Name (Column I, index 8) and the Link (Column V, index 21).
    Returns a list of tuples: [(system_name, link), ...].
    """
    print("Parsing HTML to find rows, columns...")

    # Find the main table. Some published sheets have multiple tables,
    # so you might need to refine this if your sheet is split up.
    table = soup.find("table")
    if not table:
        print("No <table> found in HTML. Check the structure of your published sheet.")
        return []

    rows = table.find_all("tr")
    print(f"Found {len(rows)} total <tr> elements in the main table.")

    parsed_data = []
    for row_index, row in enumerate(rows):
        cells = row.find_all("td")
        if len(cells) < 10:
            continue

        system_name = cells[6].get_text(strip=True)
        technologies=cells[7].get_text(strip=True)
        purpose=cells[8].get_text(strip=True)
        link_text = cells[11].get_text(strip=True)


        if not system_name and not link_text:
            continue  

        parsed_data.append((system_name, link_text,technologies,purpose))

    print(f"Parsed {len(parsed_data)} rows that had at least 11 columns.")
    return parsed_data


def setup_driver():
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)
    driver.maximize_window()
    return driver


def scrape_links(parsed_data):
    # file_path="/Users/pranavsharma/Desktop/web-scraper/AIAAIC_System_names.json"
    # with open(file_path, mode="r", encoding="utf-8") as file:
    #     all_names = json.load(file)
    
    # all_system_names=[]
    # for names in all_names:
    #     names=names.strip()
    #     all_system_names.append(names.lower())
    
        
    
    results = []
    driver = setup_driver()
    all_results=pd.DataFrame(columns=["System Name", "Technologies", "System Purpose","Entire Page"])
    os.chdir('/Users/pranavsharma/Desktop/web-scraper')
    for idx, (system_name, link, technologies, purpose) in enumerate(parsed_data, start=1):
        # system_name=system_name.strip()
        # system_name=system_name.lower()

        # if system_name not in all_system_names:
        #     continue
        if not link.lower().startswith("http"):
            print(f"Row {idx}: invalid or missing link -> '{link}'")
            continue

        print(f"Row {idx}: Opening {link} for system '{system_name}'...")
        try:
            driver.get(link)


            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )

            time.sleep(2)  

            # page_text = driver.find_element(By.TAG_NAME, "body").text

            elements = driver.find_elements(By.CSS_SELECTOR, "[id^='h.']")
            selector1_list = []
            # selector2_list = []

            for elem in elements:
                elem_id = elem.get_attribute("id")

                # Only proceed if last character is '7' or '9'
                if elem_id.endswith("2"):
                    # The text is inside the child div>div
                    try:
                        text_2 = elem.find_element(By.CSS_SELECTOR, "div > div").text
                        selector1_list.append(text_2)
                    except:
                        pass  # skip if no such child

            #     elif elem_id.endswith("9"):
            #         try:
            #             text_19 = elem.find_element(By.CSS_SELECTOR, "div > div").text
            #             selector2_list.append(text_19)
            #         except:
            #             pass

            # 3) Join the collected text
            # what_happened = "\n".join(selector1_list)
            # why_happened = "\n".join(selector2_list)


            # elements_17 = driver.find_elements(
            #     By.CSS_SELECTOR,
            #     '[id^="h."][id$="_17"] > div > div'  
            # )
            # texts_17 = [elem.text for elem in elements_17]
            # selector1_text = "\n".join(texts_17)

            # elements_19 = driver.find_elements(
            #     By.CSS_SELECTOR,
            #     '[id^="h."][id$="_19"] > div > div'   # e.g. #h\.XXXX_19 > div > div
            # )
            # texts_19 = [elem.text for elem in elements_19]
            # selector2_text = "\n".join(texts_19)

            result = pd.DataFrame({
                    "System Name": [system_name],
                    "Technologies":[technologies], 
                    "System Purpose":[purpose],
                    "Entire Page": [selector1_list],
                    # "Why Happened(Context)": [why_happened]
                })


            all_results = pd.concat([all_results, result], ignore_index=True)
            all_results.to_csv(f"AIAAIC_all_incidents.csv", index=False)

            print('done')
            
        except Exception as e:
            print(f"Row {idx}: Error scraping '{link}' -> {e}")



    driver.quit()
    return results


def save_to_csv(data, csv_file):
    if not data:
        print("No data to save!")
        return

    fieldnames = ["System Name", "Incident Description"]
    with open(csv_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

    print(f"Data successfully saved to {csv_file}")


if __name__ == "__main__":
    # 1. Fetch published HTML
    soup = fetch_published_sheet(PUBLISHED_SHEET_URL)

    # 2. Parse out system name + link from columns I (8) and V (21)
    parsed_rows = parse_sheet_data(soup)

    # 3. Use Selenium to open each link, scrape some data
    scraped_data = scrape_links(parsed_rows)

  

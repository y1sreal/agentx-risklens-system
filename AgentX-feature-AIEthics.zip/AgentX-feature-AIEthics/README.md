# facct-ai-risks-disability

### AIAAIC_context_analysis.ipynb: Contains the main code for mapping, data procesing, filtering and coring logic of the Parameters
### testcase-generation.ipynb: Conatins code to generate test cases for incidents using an Agentic Workflow, to be tested on mapped products
### image-additional-details.ipynb: Contains code to extract details from Producthunt Images extracted
### agentic-score.ipynb: Contains code dfor using AI agents to perform scoring (not used for final scoring technique)